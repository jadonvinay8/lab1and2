package lab1;

public class BasicMethods {
	
	public int calculateSum(int n){
		int sum = 0;
		
		for(int i=0 ; i<=n ; i++)
			if(i%3 == 0 || i%5 == 0)
				sum += i;
		return sum;
	}
	
	public int calculateDiff(int n) {
		int square = 0;
		int total = 0;
		
		for(int i=0 ; i<=n ; i++) {
			square += Math.pow(i, 2);
			total += i;
		}
		return square - (int)Math.pow(total, 2);
	}
	
	public boolean isIncreasing(int n) {
		boolean illegal = false;
		String num = Integer.toString(n);
		char[] numarray = num.toCharArray();
		for(int i=1 ; i<numarray.length ; i++) {
			if(Integer.parseInt(Character.toString(numarray[i])) < Integer.parseInt(Character.toString(numarray[i-1]))) {
				illegal = true;
				break;
			}
			else
				continue;
		}
		if(illegal)
			return false;
		else 
			return true;
	}
	
	public boolean isPowerOf2(int n) {
		boolean power = false;
		for(int i=2 ; i<=n ; i *= 2) {
			if(n - i == 0) {
				power = true;
				break;
			}
			else
				continue;
		}
		return power;
	}
}
