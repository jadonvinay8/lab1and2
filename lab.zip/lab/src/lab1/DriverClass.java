package lab1;

import java.util.Scanner;

public class DriverClass {

	public static void main(String[] args) {
		
		Scanner input = new Scanner(System.in);
		
		BasicMethods test = new BasicMethods();
		System.out.println("Menu: ");
		System.out.println("1. sum of n numbers divisible by 3 and 5 ");
		System.out.println("2. difference between square and sum of square of first n numbers ");
		System.out.println("3. check if number is increasing ");
		System.out.println("4. check if number is power of 2");
		System.out.println("5. Exit");
		System.out.println("Enter your choice: " );
		int choice = input.nextInt();
		System.out.println();
		
		System.out.println("Enter the number: ");
		int n = input.nextInt();

		switch(choice) {
			case 1:
				int sum = test.calculateSum(n);
				System.out.println(sum);
				break;
				
			case 2:
				int diff = test.calculateDiff(n);
				System.out.println(diff);
				break;
				
			case 3:
				boolean b1 = test.isIncreasing(n);
				System.out.println(b1);
				break;
			
			case 4:
				boolean b2 = test.isPowerOf2(n);
				System.out.println(b2);
				break;
				
			case 5: System.exit(0);
			
			default: System.out.println("invalid choice try again....");
		}
		input.close();
	}

}
